


window.addEventListener('scroll',()=>{
    console.log(window.scrollY);
    const scrollY = window.scrollY;
    const inforCard = document.querySelector('.info-card');
    const sectionHead = document.querySelector('.info-head');
    inforCard.style.opacity=scrollY/450-1;
    sectionHead.style.opacity=scrollY/250-1;

})